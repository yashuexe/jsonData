var combinations = [
    [1, 2, 3], [4, 5, 6], [7, 8, 9], [1, 4, 7], [2, 5, 8], [3, 6, 9], [1, 5, 9], [3, 5, 7]
];
var signChoosen;
window.addEventListener("load", bindEvents);
function bindEvents() {
    var options = document.querySelectorAll("div#choose div");
    options.forEach(function (i) { var _a; return (_a = document.querySelector("#".concat(i.id))) === null || _a === void 0 ? void 0 : _a.addEventListener("click", chooseTheSign); });
}
function removeEvents(name, fn) {
    var _a;
    (_a = document.querySelector("".concat(name))) === null || _a === void 0 ? void 0 : _a.removeEventListener('click', fn);
}
function chooseTheSign() {
    console.log(this);
    var currentdiv = this;
    signChoosen = currentdiv.innerText;
    removeEvents("X", chooseTheSign);
    removeEvents("O", chooseTheSign);
}
