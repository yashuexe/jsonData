const combinations = [
    [1,2,3],[4,5,6],[7,8,9],[1,4,7],[2,5,8],[3,6,9],[1,5,9],[3,5,7]
]
var signChoosen:string;

window.addEventListener("load", bindEvents);
function bindEvents():void {
    var options:NodeListOf<HTMLDivElement>  =  document.querySelectorAll("div#choose div");
    options.forEach((i:HTMLDivElement) => document.querySelector(`#${i.id}`)?.addEventListener("click",chooseTheSign));

}
function removeEvents(name,fn):void{
    document.querySelector(`${name}`)?.removeEventListener('click',fn);
}
function chooseTheSign():void{
    console.log(this);
}
